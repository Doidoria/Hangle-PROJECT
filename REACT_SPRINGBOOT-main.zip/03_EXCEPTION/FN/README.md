# LMS FN

---
DOCUMENT
---

|-|
|-|
|[DROW.io](https://app.diagrams.net/#G13sbkqpnw1ia5TnyOE14dqBs5GXnf9gmr#%7B%22pageId%22%3A%22Jf6DyvONHcGiREtb4FtZ%22%7D)|
|[FIGMA STROYBOARD](https://www.figma.com/board/WL2cw6ZWMttQlnUG6mwiW7/LMS_PROJECT_BOARD?node-id=0-1&node-type=canvas&t=CAAckVbGQqnmAJVj-0)|
|[FIGMA DISIGN](https://www.figma.com/design/QciU2qXGtsO0GYLazdOdoX/TEAM_PROJECT_LMS?node-id=0-1&node-type=canvas&t=aTYUvSXsC1SnEM13-0)|

