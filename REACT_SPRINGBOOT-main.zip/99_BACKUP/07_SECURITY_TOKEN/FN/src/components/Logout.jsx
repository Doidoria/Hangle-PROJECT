import {useState,useEffect} from 'react'
import axios from 'axios'

const Logout  = ()=>{

    return (
        <h1>LOGOUT PAGE</h1>
    )
}

export default Logout