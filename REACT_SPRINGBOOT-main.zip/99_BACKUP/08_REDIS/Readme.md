# REDIS 서버 추가하기


---
BN
---

> build.gradle

|-|
|-|
|<img src="./IMG/1_REDIS_BN/1/1.png" />|

> Redis files

|-|
|-|
|<img src="./IMG/1_REDIS_BN/2/1.png" />|
|<img src="./IMG/1_REDIS_BN/2/2.png" />|
|<img src="./IMG/1_REDIS_BN/2/3.png" />|
|<img src="./IMG/1_REDIS_BN/2/4.png" />|

> 기존 파일 수정 

|-|
|-|
|<img src="./IMG/1_REDIS_BN/3/1.png" />|
|<img src="./IMG/1_REDIS_BN/3/2.png" />|
|<img src="./IMG/1_REDIS_BN/3/3.png" />|
|<img src="./IMG/1_REDIS_BN/3/4.png" />|
|<img src="./IMG/1_REDIS_BN/3/5.png" />|
|<img src="./IMG/1_REDIS_BN/3/6.png" />|
|<img src="./IMG/1_REDIS_BN/3/7.png" />|

|-|
|-|
|<img src="./IMG/1_REDIS_BN/4/1.png" />|
|<img src="./IMG/1_REDIS_BN/4/2.png" />|

|-|
|-|
|<img src="./IMG/1_REDIS_BN/5/6.png" />|


---
FN
---

>

|-|
|-|
|<img src="./IMG/2_REDIS_FN/1.png" />|
|<img src="./IMG/2_REDIS_FN/2.png" />|
|<img src="./IMG/2_REDIS_FN/3.png" />|
|<img src="./IMG/2_REDIS_FN/4.png" />|


---
확인
---

>

|-|
|-|
|<img src="./IMG/3_RESULT/1.png" />|
|<img src="./IMG/3_RESULT/2.png" />|
|<img src="./IMG/3_RESULT/3.png" />|
|<img src="./IMG/3_RESULT/4.png" />|
|<img src="./IMG/3_RESULT/5.png" />|
|<img src="./IMG/3_RESULT/6.png" />|
|<img src="./IMG/3_RESULT/7.png" />|
|<img src="./IMG/3_RESULT/8.png" />|
|<img src="./IMG/3_RESULT/9.png" />|
|<img src="./IMG/3_RESULT/10.png" />|
|<img src="./IMG/3_RESULT/11.png" />|
|<img src="./IMG/3_RESULT/12.png" />|



