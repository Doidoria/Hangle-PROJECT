import logo from './logo.svg';
import './App.css';

import Param from './components/Param'
function App() {
  return (
    <div className="App">
        <Param />
    </div>
  );
}

export default App;
