package com.example.demo.domain.repository;

import com.example.demo.domain.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional; // Optional 임포트 추가

@Repository
public interface UserRepository extends JpaRepository<User,String> {
    User findByUsername(String username);

    // 이메일 중복 확인을 위한 메서드 추가
    Optional<User> findByEmail(String email);
}