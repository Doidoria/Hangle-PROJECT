package com.example.demo.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 사용자 설정 변경 (이름, 이메일 수정 + 비밀번호 확인용 DTO)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SettingsUpdateDto {
    private String name;             // 변경할 이름
    private String email;            // 변경할 이메일
    private String currentPassword;  // 현재 비밀번호 (검증용)
}
