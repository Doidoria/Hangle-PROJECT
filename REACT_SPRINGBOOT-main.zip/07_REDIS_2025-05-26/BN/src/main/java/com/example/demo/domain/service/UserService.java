package com.example.demo.domain.service;

import com.example.demo.domain.dto.ProfileDto;
import com.example.demo.domain.dto.SettingsUpdateDto;
import com.example.demo.domain.entity.User;
import com.example.demo.domain.repository.UserRepository;
import com.example.demo.domain.exception.CustomValidationException;
import com.example.demo.domain.exception.ResourceNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // (TODO: RedisUtil, SmsService 등 주입 필요)

    // 1. 프로필 조회
    public ProfileDto getProfile(String username) {
        User user = userRepository.findById(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with username: " + username));
        return ProfileDto.toDto(user);
    }

    // 2. 이름 및 이메일 수정
    @Transactional
    public ProfileDto updateSettings(String username, SettingsUpdateDto dto) {
        User user = userRepository.findById(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found."));

        // 비밀번호 확인 (보안 필수)
        if (!passwordEncoder.matches(dto.getCurrentPassword(), user.getPassword())) {
            throw new CustomValidationException("Current password is incorrect.");
        }

        // 이름 수정
        if (dto.getName() != null && !dto.getName().isBlank()) {
            user.setName(dto.getName());
        }

        // 이메일 수정 및 중복 검사
        if (dto.getEmail() != null && !dto.getEmail().isBlank()) {
            if (!dto.getEmail().equals(user.getEmail())) {
                if (userRepository.findByEmail(dto.getEmail()).isPresent()) { // 새로 추가할 findByEmail 필요
                    throw new CustomValidationException("Email is already in use.");
                }
                user.setEmail(dto.getEmail());
            }
        }

        // 폰 인증, 이미지 등 추가 수정 로직 삽입 가능
        return ProfileDto.toDto(userRepository.save(user));
    }

    // 3. 계정 삭제
    @Transactional
    public void deleteAccount(String username, String currentPassword) {
        User user = userRepository.findById(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found."));

        // 비밀번호 확인 (보안 필수)
        if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
            throw new CustomValidationException("Current password is incorrect.");
        }

        // TODO: 관련 데이터 (게시글, 댓글 등) 삭제/익명화 로직 추가

        // 사용자 삭제
        userRepository.delete(user);
    }

    // 4. 폰 인증 관련 로직 (TODO: 외부 SMS 연동 필요)
    public void sendVerificationCode(String phoneNumber) {
        // ... (인증번호 생성, Redis 저장, SMS API 호출 로직)
        throw new UnsupportedOperationException("SMS Service not yet implemented.");
    }

    @Transactional
    public void confirmVerificationCode(String username, String code) {
        // ... (Redis에서 코드 확인 및 User 엔티티의 isPhoneVerified 업데이트 로직)
        throw new UnsupportedOperationException("SMS Service not yet implemented.");
    }
}