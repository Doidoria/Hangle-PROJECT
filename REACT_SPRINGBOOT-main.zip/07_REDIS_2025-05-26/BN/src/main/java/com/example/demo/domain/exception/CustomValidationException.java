package com.example.demo.domain.exception;

/**
 * 사용자 입력값이 잘못되었을 때 발생하는 예외
 */
public class CustomValidationException extends RuntimeException {
    public CustomValidationException(String message) {
        super(message);
    }
}
