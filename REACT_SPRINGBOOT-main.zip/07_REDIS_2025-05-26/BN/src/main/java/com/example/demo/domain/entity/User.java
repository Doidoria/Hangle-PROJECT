package com.example.demo.domain.entity;

import jakarta.persistence.Column; // Column 추가
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
public class User {
    @Id
    private String username;
    private String password;
    private String role;

    // --- [프로필 정보 추가] ---
    private String name; // 사용자 이름 (수정 가능)
    private String profileImageUrl; // 프로필 이미지 URL

    // --- [설정/인증 정보 추가] ---
    @Column(unique = true) // 이메일은 중복되면 안 되므로 unique 추가
    private String email;
    private String phoneNumber; // 전화번호
    private Boolean isPhoneVerified; // 폰 인증 여부

}