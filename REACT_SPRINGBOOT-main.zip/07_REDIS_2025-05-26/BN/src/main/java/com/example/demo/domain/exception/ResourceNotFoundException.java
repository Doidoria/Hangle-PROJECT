package com.example.demo.domain.exception;

/**
 * 존재하지 않는 리소스(예: 사용자, 게시글 등)에 접근할 때 발생하는 예외
 */
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
