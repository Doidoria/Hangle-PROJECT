import {useState,useEffect} from 'react'
import axios from 'axios'

const Main  = ()=>{

    return (
        <h1>MAIN PAGE</h1>
    )
}

export default Main