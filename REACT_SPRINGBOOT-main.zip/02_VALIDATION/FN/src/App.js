import logo from './logo.svg';
import './App.css';

import Param from './components/Param'
import Memo from './components/Memo'
function App() {
  return (
    <div className="App">
        {/* <Param /> */}

        <Memo />
    </div>
  );
}

export default App;
