package com.example.demo.domain.inquiry.dto;

import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class InquiryAnswerRequestDto {
    private String answerContent;
}
