import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:8090", // 백엔드 서버 포트 8090으로 설정
  withCredentials: true,
});

// ==========================
// 공용 경로(인증 제외)
// ==========================
const PUBLIC_PATHS = [
  "/login",
  "/join",
  "/validate",
  "/oauth2",
];

// 제출 API는 validate 검사 제외 (토큰만 확인)
const isSubmitAPI = (url) =>
  url.includes("/api/competitions") && url.includes("/submit");

// ==========================
// 요청 인터셉터: Access Token 설정 및 유효성 검사
// ==========================
api.interceptors.request.use(
  async (config) => {
    const token = localStorage.getItem("accessToken");

    // 🔥 Authorization 헤더 자동 설정
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    const url = config.url || "";

    // 🔥 공용 API 또는 제출 API는 validate 스킵
    if (PUBLIC_PATHS.some((path) => url.startsWith(path)) || isSubmitAPI(url)) {
      return config;
    }

    // ================================
    // 🔥 validate 인증 검사
    // ================================
    try {
      // validate API를 호출하여 토큰 유효성 검증
      await api.get("/validate");
      return config;
    } catch (err) {
      console.warn("❌ validate 실패. 토큰 만료 또는 유효하지 않음.");
      // window.location.href 대신 이 경우 Promise.reject를 통해 요청을 중단하고 
      // 앱 내에서 인증 처리 모달 등을 띄우도록 할 수도 있지만, 
      // 여기서는 기본적으로 로그인 페이지로 이동합니다.
      window.location.href = "/login";
      return Promise.reject("인증 필요");
    }
  },
  (error) => Promise.reject(error)
);

// ==========================
// 응답 인터셉터: 401 에러 발생 시 Access Token 재발급 시도
// ==========================
api.interceptors.response.use(
  (response) => response,

  async (error) => {
    const originalRequest = error.config;
    const isRefreshRequest = originalRequest.url && originalRequest.url.includes("/refresh");

    // accessToken 만료 (401) 및 재시도 플래그가 없는 경우
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      // 🔥 루프 방지: 만약 현재 요청이 '/refresh'이고 401을 받았다면
      if (isRefreshRequest) {
        console.error("❌ Refresh Token 재발급 실패 → 로그인 이동");
        window.location.href = "/login";
        return Promise.reject(error);
      }

      try {
        // Refresh Token을 사용하여 새 Access Token 요청
        const refreshRes = await api.post("/refresh", null, {
          withCredentials: true,
        });

        const newAccessToken = refreshRes.data?.accessToken;

        if (newAccessToken) {
          localStorage.setItem("accessToken", newAccessToken);

          // 헤더 갱신 후 원래 요청 재시도
          originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
          return api(originalRequest);
        }
      } catch (refreshErr) {
        // Refresh Token 요청 자체 실패 시
        console.error("❌ Refresh Token 재발급 실패 → 로그인 이동");
        window.location.href = "/login";
        return Promise.reject(refreshErr);
      }
    }

    return Promise.reject(error);
  }
);

export default api;