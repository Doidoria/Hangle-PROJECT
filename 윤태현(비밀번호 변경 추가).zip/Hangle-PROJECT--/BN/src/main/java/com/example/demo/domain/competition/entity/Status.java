package com.example.demo.domain.competition.entity;

public enum Status {
    OPEN, CLOSED, UPCOMING
}
