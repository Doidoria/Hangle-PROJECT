import React, { useState, useEffect, useCallback } from 'react';
import api from '../api/axiosConfig';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';
import '../css/MyInquiries.scss';

function MyInquiries() {
    const [inquiries, setInquiries] = useState([]);
    const [filtered, setFiltered] = useState([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');
    const [statusFilter, setStatusFilter] = useState('전체');
    const [sortOrder, setSortOrder] = useState('desc');
    const [dateFilter, setDateFilter] = useState('전체');
    const [modalData, setModalData] = useState(null);
    const navigate = useNavigate();

    // 답변 완료 여부를 판단하는 헬퍼 함수
    const isAnswered = (inq) => inq.answerContent && inq.answerContent.trim().length > 0;

    useEffect(() => {
        fetchMyInquiries();
    }, []);

    const fetchMyInquiries = async () => {
        setLoading(true);
        try {
            const res = await api.get('/api/inquiry/my');
            setInquiries(res.data);
            setFiltered(res.data);
        } catch (err) {
            Swal.fire({ icon: 'error', title: '조회 실패', text: '문의 목록을 불러올 수 없습니다.' });
        } finally {
            setLoading(false);
        }
    };

    // 필터 적용 로직
    useEffect(() => {
        let data = [...inquiries];

        // 검색
        if (search.trim()) {
            data = data.filter(i => i.title.toLowerCase().includes(search.toLowerCase()));
        }

        // 상태 필터: statusFilter가 변경될 때마다 적용됨 (버튼 클릭 포함)
        if (statusFilter === '답변완료') {
            data = data.filter(isAnswered);
        } else if (statusFilter === '답변대기') {
            data = data.filter(i => !isAnswered(i));
        }
        // '전체'일 경우 필터링 없음

        // 기간 필터 (기존 로직 유지)
        if (dateFilter !== '전체') {
            const now = new Date();
            const compareDate = new Date(
                dateFilter === '1개월' ? now.setMonth(now.getMonth() - 1)
                    : now.setMonth(now.getMonth() - 3)
            );
            data = data.filter(i => new Date(i.createdAt) >= compareDate);
        }

        // 정렬
        data.sort((a, b) =>
            sortOrder === 'desc'
                ? new Date(b.createdAt) - new Date(a.createdAt)
                : new Date(a.createdAt) - new Date(b.createdAt)
        );

        setFiltered(data);
    }, [search, statusFilter, sortOrder, dateFilter, inquiries]);

    // 통계 계산
    const totalCount = inquiries.length;
    const answeredCount = inquiries.filter(isAnswered).length;
    const pendingCount = totalCount - answeredCount;

    // 답변 상태 텍스트
    const getStatusText = inq => (isAnswered(inq) ? '답변 완료' : '접수');

    const handleDelete = async (id, e) => {
        e.stopPropagation(); // 행 클릭 시 모달 안 뜨게 방지

        const result = await Swal.fire({
            title: '문의 삭제',
            text: '정말로 이 문의를 삭제하시겠습니까?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: '삭제',
            cancelButtonText: '취소',
            confirmButtonColor: '#e11d48', // 붉은색
        });

        if (result.isConfirmed) {
            try {
                await api.delete(`/api/inquiry/${id}`);
                Swal.fire('삭제 완료', '문의가 삭제되었습니다.', 'success');
                fetchMyInquiries(); // 목록 새로고침
            } catch (err) {
                Swal.fire('삭제 실패', '서버 오류로 삭제할 수 없습니다.', 'error');
            }
        }
    };

    // 카드 버튼 클릭 핸들러: statusFilter를 업데이트하고 검색창을 비웁니다.
    const handleStatusCardClick = (status) => {
        setStatusFilter(status);
        setSearch(''); // 상태 필터 시 검색 초기화
    };


    return (
        <div className="my-inquiries-container">
            {/* 고객센터로 이동 버튼 */}
            <button
                className="go-faq-btn"
                onClick={() => navigate("/FaqPage")}
            >
                <span class="material-symbols-outlined">arrow_left</span>
                <span class="material-symbols-outlined">support_agent</span>
            </button>
            <h2>나의 1:1 문의 내역</h2>

            {/* 통계 버튼 카드 */}
            <div className="inquiry-stats">
                <button
                    className={`stat-card total ${statusFilter === '전체' ? 'active' : ''}`}
                    onClick={() => handleStatusCardClick('전체')}
                >
                    전체 <span>{totalCount}</span>
                </button>
                <button
                    className={`stat-card pending ${statusFilter === '답변대기' ? 'active' : ''}`}
                    onClick={() => handleStatusCardClick('답변대기')}
                >
                    대기 <span>{pendingCount}</span>
                </button>
                <button
                    className={`stat-card done ${statusFilter === '답변완료' ? 'active' : ''}`}
                    onClick={() => handleStatusCardClick('답변완료')}
                >
                    완료 <span>{answeredCount}</span>
                </button>
            </div>

            {/* 필터 영역 */}
            <div className="inquiry-filters">
                <input
                    type="text"
                    placeholder="문의 제목 검색"
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                />
                <select value={dateFilter} onChange={e => setDateFilter(e.target.value)}>
                    <option>전체</option>
                    <option>1개월</option>
                    <option>3개월</option>
                </select>
                <select value={sortOrder} onChange={e => setSortOrder(e.target.value)}>
                    <option value="desc">최신순</option>
                    <option value="asc">오래된순</option>
                </select>
            </div>

            {/* 목록 */}
            {loading ? (
                <div className="loading">목록을 불러오는 중...</div>
            ) : filtered.length === 0 ? (
                <p className="no-data">문의 내역이 없습니다.</p>
            ) : (
                <table className="inquiry-table">
                    <thead>
                        <tr>
                            <th>번호</th>
                            <th>제목</th>
                            <th>작성일</th>
                            <th>상태</th>
                            <th>답변일</th>
                            <th> - </th>
                        </tr>
                    </thead>
                    <tbody>
                        {filtered.map((inq, index) => (
                            <tr key={inq.id} onClick={() => setModalData(inq)}>
                                <td>{index + 1}</td>
                                <td className="title">
                                    {inq.title}
                                </td>
                                <td>{new Date(inq.createdAt).toLocaleDateString()}</td>
                                <td className={isAnswered(inq) ? 'status done' : 'status pending'}>
                                    {getStatusText(inq)}
                                </td>
                                <td>{inq.answerDate ? new Date(inq.answerDate).toLocaleDateString() : '-'}</td>
                                <td>
                                    <button
                                        className="delete-btn"
                                        onClick={(e) => handleDelete(inq.id, e)}
                                    >
                                        삭제
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}

            {/* 문의작성 버튼 */}
            <button className="floating-btn" onClick={() => navigate('/inquiry/write')}>
                <span class="material-symbols-outlined">edit_square</span>
                <span>문의 작성</span>
            </button>

            {/* 모달 */}
            {modalData && (
                <div className="modal-overlay" onClick={() => setModalData(null)}>
                    <div className="modal" onClick={(e) => e.stopPropagation()}>

                        <p className="modal-date">
                            작성일: {new Date(modalData.createdAt).toLocaleDateString()}
                        </p>

                        {/* 수정 모드 상태 */}
                        {modalData.editMode ? (
                            <input
                                className="edit-title-input"
                                value={modalData.title}
                                onChange={(e) =>
                                    setModalData({ ...modalData, title: e.target.value })
                                }
                            />
                        ) : (
                            <h3>{modalData.title}</h3>
                        )}

                        {/* 문의 내용 */}
                        <div className="modal-card">
                            <strong>문의 내용</strong>

                            {modalData.editMode ? (
                                <textarea
                                    className="edit-content-textarea"
                                    value={modalData.content}
                                    onChange={(e) =>
                                        setModalData({ ...modalData, content: e.target.value })
                                    }
                                />
                            ) : (
                                <p>
                                    <span className="material-symbols-outlined faq-icon">question_mark</span>
                                    {modalData.content}
                                </p>
                            )}
                        </div>

                        {/* 답변 내용 */}
                        <div className="modal-card">
                            <strong>답변</strong>
                            <p>
                                <span className="material-symbols-outlined faq-icon">campaign</span>
                                {modalData.answerContent || '아직 답변이 등록되지 않았습니다.'}
                            </p>

                            {modalData.answerDate && (
                                <p className="text-xs text-gray-500 mt-2 pt-2 border-t border-gray-200">
                                    답변일: {new Date(modalData.answerDate).toLocaleDateString()}
                                </p>
                            )}
                        </div>

                        {/* 버튼 영역 */}
                        <div className="modal-buttons">

                            {/* 수정 가능: 답변이 없을 때만 */}
                            {!modalData.answerContent && !modalData.editMode && (
                                <button
                                    className="edit-btn"
                                    onClick={() =>
                                        setModalData({ ...modalData, editMode: true })
                                    }
                                >
                                    <span className="material-symbols-outlined faq-modal-icon">edit</span>
                                    수정하기
                                </button>
                            )}

                            {/* 저장 버튼 (editMode일 때만 노출) */}
                            {modalData.editMode && (
                                <button
                                    className="edit-btn"
                                    onClick={async () => {
                                        try {
                                            await api.put(`/api/inquiry/${modalData.id}`, {
                                                title: modalData.title,
                                                content: modalData.content,
                                            });

                                            Swal.fire({
                                                icon: "success",
                                                title: "수정 완료",
                                                text: "문의 내용이 수정되었습니다."
                                            });

                                            setModalData(null); // 모달 닫기
                                            fetchMyInquiries(); // 목록 갱신
                                        } catch (err) {
                                            Swal.fire({
                                                icon: "error",
                                                title: "수정 실패",
                                                text: "서버 오류로 수정할 수 없습니다."
                                            });
                                        }
                                    }}
                                >
                                    <span className="material-symbols-outlined faq-modal-icon">check</span>
                                    저장
                                </button>
                            )}

                            {/* 닫기 버튼 */}
                            <button
                                className="close-btn"
                                onClick={() => setModalData(null)}
                            >
                                <span className="material-symbols-outlined faq-modal-icon">close</span>
                                닫기
                            </button>
                        </div>
                    </div>
                </div>
            )}

        </div>
    );
}

export default MyInquiries;