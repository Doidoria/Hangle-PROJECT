package com.example.demo.domain.inquiry.dto;

import lombok.Data;

@Data
public class InquiryAnswerRequestDto {
    private String answerContent;
}
